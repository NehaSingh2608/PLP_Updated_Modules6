package com.cg.capstore.service;


import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.MerchantAlreadyExist;

public interface IMerchantService {

	public Merchant registerMerchant(Merchant merchant)  throws MerchantAlreadyExist;
	public Address addAddress(Address address, String id);
}
