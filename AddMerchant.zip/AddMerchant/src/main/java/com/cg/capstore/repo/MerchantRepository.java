package com.cg.capstore.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.MerchantAlreadyExist;




@Transactional
@Repository
public class MerchantRepository implements  IMerchantRepository{

	@PersistenceContext
	EntityManager entity;

	@Override
	public Merchant registerMerchant(Merchant merchant) throws MerchantAlreadyExist {
	
		entity.persist(merchant);
		System.out.println(merchant);
		return merchant;
	}

	@Override
	public Address addAddress(Address address, String id) {
	
		System.out.println(address);
		Random random=new Random();
		String addressId="A#"+Integer.toString(random.nextInt(100));
		address.setAddressId(addressId);
		
		List<Address> list=new ArrayList<>();
		list.add(address);
		
		
		Merchant merchant=entity.find(Merchant.class,id);
		merchant.setAddresses(list);
		System.out.println(merchant.getMerchantMobileNo());
		
		address.setMerchantId(merchant);
		entity.merge(merchant);
		
		System.out.println(address.getAddressId());
		
		return address;
	}
	
}
