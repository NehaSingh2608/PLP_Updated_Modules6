package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.MerchantAlreadyExist;
import com.cg.capstore.repo.IMerchantRepository;




@Service
public class MercahntService implements IMerchantService{

	@Autowired
	IMerchantRepository repo;

	@Override
	public Merchant registerMerchant(Merchant merchant) throws MerchantAlreadyExist {
			return repo.registerMerchant(merchant);
	}

	@Override
	public Address addAddress(Address address, String id) {
		
		return repo.addAddress(address,id);
	}
	
	
	
}
