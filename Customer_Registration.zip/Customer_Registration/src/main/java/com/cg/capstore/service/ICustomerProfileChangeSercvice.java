package com.cg.capstore.service;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.exception.CustomerdoesnotExist;


public interface ICustomerProfileChangeSercvice  {

	Customer changeProfile(Customer customer) throws CustomerdoesnotExist;
}
